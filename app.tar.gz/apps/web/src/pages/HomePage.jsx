
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Sparkles, Heart, Scissors, Droplet, Wind, Flower2, Phone, MapPin, Mail, MessageCircle } from 'lucide-react';
import Header from '@/components/Header.jsx';
import ServiceCard from '@/components/ServiceCard.jsx';
import GalleryCard from '@/components/GalleryCard.jsx';
import TestimonialCard from '@/components/TestimonialCard.jsx';
import PricingTable from '@/components/PricingTable.jsx';
import ContactForm from '@/components/ContactForm.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button';
import { Toaster } from '@/components/ui/sonner';

const HomePage = () => {
  const services = [
    {
      icon: Heart,
      title: 'Bridal Makeup',
      description: 'Complete bridal transformation with premium products and expert techniques for your special day.',
      image: 'https://images.unsplash.com/photo-1638628064365-f08ad0ec8245'
    },
    {
      icon: Sparkles,
      title: 'Party Makeup',
      description: 'Glamorous looks for special occasions, parties, and events that make you stand out.',
      image: 'https://images.unsplash.com/flagged/photo-1571839704068-775b67193288'
    },
    {
      icon: Scissors,
      title: 'Hair Styling',
      description: 'Professional cuts, colors, and styling services for all hair types and occasions.',
      image: 'https://images.unsplash.com/photo-1587225438173-701d7edc94f9'
    },
    {
      icon: Droplet,
      title: 'Facial & Skincare',
      description: 'Rejuvenating treatments for glowing, healthy skin using premium skincare products.',
      image: 'https://images.unsplash.com/photo-1542848285-0d50a56a0dfc'
    },
    {
      icon: Wind,
      title: 'Waxing & Cleanup',
      description: 'Smooth, hair-free skin with gentle care and professional waxing techniques.',
      image: 'https://images.unsplash.com/photo-1519415387722-a1c3bbef716c'
    },
    {
      icon: Flower2,
      title: 'Mehndi Design',
      description: 'Traditional and contemporary henna art for weddings, festivals, and celebrations.',
      image: 'https://images.unsplash.com/photo-1568566164571-a93f53e165d5'
    }
  ];

  const galleryItems = [
    {
      image: 'https://images.unsplash.com/photo-1699726242741-11e3ccc06610',
      title: 'Bridal Elegance',
      category: 'Bridal Makeup'
    },
    {
      image: 'https://images.unsplash.com/photo-1638628064365-f08ad0ec8245',
      title: 'Traditional Beauty',
      category: 'Bridal Makeup'
    },
    {
      image: 'https://images.unsplash.com/photo-1677808566807-1097fc06b472',
      title: 'Party Glam',
      category: 'Party Makeup'
    },
    {
      image: 'https://images.unsplash.com/flagged/photo-1571839704068-775b67193288',
      title: 'Evening Look',
      category: 'Party Makeup'
    },
    {
      image: 'https://images.unsplash.com/photo-1560869713-bf165a9cfac1',
      title: 'Hair Artistry',
      category: 'Hair Styling'
    },
    {
      image: 'https://images.unsplash.com/photo-1683917335316-ddb0d64f7568',
      title: 'Glowing Skin',
      category: 'Facial Treatment'
    },
    {
      image: 'https://images.unsplash.com/photo-1675261109536-e3137b25ffbb',
      title: 'Mehndi Art',
      category: 'Mehndi Design'
    },
    {
      image: 'https://images.unsplash.com/photo-1544877095-85101b8174d5',
      title: 'Transformation',
      category: 'Before & After'
    }
  ];

  const testimonials = [
    {
      name: 'Priya Sharma',
      feedback: 'The bridal makeup was absolutely stunning. The team understood exactly what I wanted and made me feel like a princess on my wedding day.',
      rating: 5,
      service: 'Bridal Makeup'
    },
    {
      name: 'Anjali Verma',
      feedback: 'Amazing party makeup service. The makeup lasted all night and I received so many compliments. Highly recommend for special occasions.',
      rating: 5,
      service: 'Party Makeup'
    },
    {
      name: 'Neha Kapoor',
      feedback: 'Best hair styling experience. The stylist was professional and gave me exactly the look I wanted. Will definitely come back.',
      rating: 5,
      service: 'Hair Styling'
    },
    {
      name: 'Ritu Malhotra',
      feedback: 'The facial treatment was so relaxing and my skin has never looked better. The products used are of premium quality.',
      rating: 5,
      service: 'Facial & Skincare'
    },
    {
      name: 'Kavita Singh',
      feedback: 'Excellent service and very professional staff. The parlour is clean, well-maintained, and the atmosphere is welcoming.',
      rating: 5,
      service: 'Overall Experience'
    }
  ];

  const whatsappMessage = encodeURIComponent('I want to book an appointment at Priyanshi Beauty Parlour');
  const whatsappLink = `https://wa.me/919265371481?text=${whatsappMessage}`;

  const handleBookAppointment = () => {
    window.open(whatsappLink, '_blank');
  };

  return (
    <>
      <Helmet>
        <title>Priyanshi Beauty Parlour - Exclusive Women's Salon</title>
        <meta
          name="description"
          content="Premium beauty services including bridal makeup, party makeup, hair styling, facials, and more. Book your appointment today at Priyanshi Beauty Parlour, an exclusive women's salon in Surat."
        />
      </Helmet>

      <div className="min-h-screen">
        <Header />
        <Toaster />

        {/* Hero Section */}
        <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0">
            <img
              src="https://images.unsplash.com/photo-1601396253987-5a184958a04b"
              alt="Priyanshi Beauty Parlour - Professional beauty services"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-black/30"></div>
          </div>
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="mb-6"
            >
              <span className="inline-block px-4 py-1.5 rounded-full bg-accent/20 border border-accent/30 text-accent font-semibold text-sm tracking-widest uppercase backdrop-blur-sm">
                Exclusive Women's Salon
              </span>
            </motion.div>
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.1 }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight"
              style={{ fontFamily: 'Playfair Display, serif', letterSpacing: '-0.02em' }}
            >
              Enhancing Your Natural Beauty
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-xl md:text-2xl text-white/90 mb-8 max-w-2xl mx-auto leading-relaxed"
            >
              Professional Makeup, Skincare & Hair Services
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              <Button
                size="lg"
                className="bg-accent text-accent-foreground hover:bg-accent/90 text-lg px-8 py-6 transition-all duration-200 active:scale-[0.98]"
                onClick={handleBookAppointment}
              >
                Book Appointment
              </Button>
            </motion.div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="py-20 bg-muted">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h2
                className="text-3xl md:text-4xl font-bold text-foreground mb-4"
                style={{ fontFamily: 'Playfair Display, serif' }}
              >
                About Priyanshi Beauty Parlour
              </h2>
              <div className="w-24 h-1 bg-accent mx-auto mb-6"></div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="max-w-3xl mx-auto"
            >
              <p className="text-lg text-foreground leading-relaxed mb-6">
                Welcome to Priyanshi Beauty Parlour, an exclusive women's salon where beauty meets expertise. With years of experience in the beauty industry, we have built a reputation for trust, quality, and exceptional service in a comfortable, women-only environment.
              </p>
              <p className="text-lg text-foreground leading-relaxed mb-6">
                Our team of skilled professionals uses only premium products and the latest techniques to enhance your natural beauty. Whether you're preparing for your wedding day, a special event, or simply want to pamper yourself, we're here to make you look and feel your absolute best.
              </p>
              <p className="text-lg text-foreground leading-relaxed">
                We believe in creating a warm, welcoming atmosphere where every client feels valued and cared for. Your satisfaction is our priority, and we're committed to delivering results that exceed your expectations.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Services Section */}
        <section id="services" className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h2
                className="text-3xl md:text-4xl font-bold text-foreground mb-4"
                style={{ fontFamily: 'Playfair Display, serif' }}
              >
                Our Services
              </h2>
              <div className="w-24 h-1 bg-accent mx-auto mb-6"></div>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Discover our range of professional beauty services designed to enhance your natural radiance
              </p>
            </motion.div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {services.map((service, index) => (
                <ServiceCard key={service.title} {...service} index={index} />
              ))}
            </div>
          </div>
        </section>

        {/* Gallery Section */}
        <section id="gallery" className="py-20 bg-muted">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h2
                className="text-3xl md:text-4xl font-bold text-foreground mb-4"
                style={{ fontFamily: 'Playfair Display, serif' }}
              >
                Our Portfolio
              </h2>
              <div className="w-24 h-1 bg-accent mx-auto mb-6"></div>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Explore our work and see the transformations we've created for our valued clients
              </p>
            </motion.div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {galleryItems.map((item, index) => (
                <GalleryCard key={index} {...item} index={index} />
              ))}
            </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section id="pricing" className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h2
                className="text-3xl md:text-4xl font-bold text-foreground mb-4"
                style={{ fontFamily: 'Playfair Display, serif' }}
              >
                Our Pricing
              </h2>
              <div className="w-24 h-1 bg-accent mx-auto mb-6"></div>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Transparent pricing for premium beauty services
              </p>
            </motion.div>
            <PricingTable />
          </div>
        </section>

        {/* Testimonials Section */}
        <section id="testimonials" className="py-20 bg-muted">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h2
                className="text-3xl md:text-4xl font-bold text-foreground mb-4"
                style={{ fontFamily: 'Playfair Display, serif' }}
              >
                What Our Clients Say
              </h2>
              <div className="w-24 h-1 bg-accent mx-auto mb-6"></div>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Read testimonials from our satisfied clients
              </p>
            </motion.div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {testimonials.map((testimonial, index) => (
                <TestimonialCard key={index} {...testimonial} index={index} />
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-primary text-primary-foreground">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-3xl md:text-4xl font-bold mb-6"
              style={{ fontFamily: 'Playfair Display, serif' }}
            >
              Book Your Appointment Today
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg mb-8 leading-relaxed"
            >
              Ready to enhance your natural beauty? Contact us on WhatsApp to schedule your appointment
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <Button
                size="lg"
                className="bg-accent text-accent-foreground hover:bg-accent/90 text-lg px-8 py-6 transition-all duration-200 active:scale-[0.98]"
                onClick={handleBookAppointment}
              >
                <MessageCircle className="w-5 h-5 mr-2" />
                Chat on WhatsApp
              </Button>
            </motion.div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h2
                className="text-3xl md:text-4xl font-bold text-foreground mb-4"
                style={{ fontFamily: 'Playfair Display, serif' }}
              >
                Get In Touch
              </h2>
              <div className="w-24 h-1 bg-accent mx-auto mb-6"></div>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                We'd love to hear from you. Reach out to us for appointments or inquiries
              </p>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <h3
                  className="text-2xl font-semibold mb-6 text-foreground"
                  style={{ fontFamily: 'Playfair Display, serif' }}
                >
                  Contact Information
                </h3>
                <div className="space-y-6 mb-8">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center flex-shrink-0">
                      <Phone className="w-6 h-6 text-accent" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground mb-1">Phone</p>
                      <a
                        href="tel:+919265371481"
                        className="text-muted-foreground hover:text-accent transition-colors duration-200"
                      >
                        +91 92653 71481
                      </a>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center flex-shrink-0">
                      <MessageCircle className="w-6 h-6 text-accent" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground mb-1">WhatsApp</p>
                      <a
                        href={whatsappLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-muted-foreground hover:text-accent transition-colors duration-200"
                      >
                        Chat with us on WhatsApp
                      </a>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center flex-shrink-0">
                      <Mail className="w-6 h-6 text-accent" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground mb-1">Email</p>
                      <a
                        href="mailto:info@priyanshi.com"
                        className="text-muted-foreground hover:text-accent transition-colors duration-200"
                      >
                        info@priyanshi.com
                      </a>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center flex-shrink-0">
                      <MapPin className="w-6 h-6 text-accent" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground mb-1">Address</p>
                      <p className="text-muted-foreground leading-relaxed">
                        10, Sanam Apartment, Archana, to, Sitanagar Road, Punagam, Surat, Gujarat 395011
                      </p>
                    </div>
                  </div>
                </div>

                <div className="rounded-xl overflow-hidden shadow-lg">
                  <iframe
                    src="https://www.openstreetmap.org/export/embed.html?bbox=72.8279%2C21.1258%2C72.8679%2C21.1658&layer=mapnik&marker=21.1458%2C72.8479"
                    width="100%"
                    height="300"
                    style={{ border: 0 }}
                    loading="lazy"
                    title="Priyanshi Beauty Parlour Location"
                  ></iframe>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="bg-muted rounded-2xl p-8 shadow-lg"
              >
                <h3
                  className="text-2xl font-semibold mb-6 text-foreground"
                  style={{ fontFamily: 'Playfair Display, serif' }}
                >
                  Send Us a Message
                </h3>
                <ContactForm />
              </motion.div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default HomePage;
