
import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';

const formSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Please enter a valid email address'),
  phone: z.string().min(10, 'Please enter a valid phone number'),
  service: z.string().min(1, 'Please select a service'),
  message: z.string().min(10, 'Message must be at least 10 characters'),
});

const ContactForm = () => {
  const { toast } = useToast();
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    reset,
    setValue,
    watch,
  } = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      email: '',
      phone: '',
      service: '',
      message: '',
    },
  });

  const selectedService = watch('service');

  const onSubmit = async (data) => {
    try {
      // Save locally
      const submissions = JSON.parse(localStorage.getItem('contactSubmissions') || '[]');
      const newSubmission = {
        ...data,
        timestamp: new Date().toISOString(),
        id: Date.now(),
      };
      submissions.push(newSubmission);
      localStorage.setItem('contactSubmissions', JSON.stringify(submissions));

      // Generate WhatsApp link
      const waText = `Hello, I would like to book an appointment.%0A%0A*Name:* ${data.name}%0A*Phone:* ${data.phone}%0A*Email:* ${data.email}%0A*Service:* ${data.service}%0A*Message:* ${data.message}`;
      const waUrl = `https://wa.me/919265371481?text=${waText}`;
      
      // Open WhatsApp in new tab
      window.open(waUrl, '_blank');

      toast({
        title: 'Redirecting to WhatsApp',
        description: 'Your message is ready to be sent.',
      });

      reset();
    } catch (error) {
      toast({
        title: 'Failed to process request',
        description: 'Please try again later.',
        variant: 'destructive',
      });
    }
  };

  const services = [
    'Bridal Makeup',
    'Party Makeup',
    'Hair Styling',
    'Facial & Skincare',
    'Waxing & Cleanup',
    'Mehndi Design',
    'Other',
  ];

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div>
        <Label htmlFor="name" className="text-foreground font-medium">
          Name *
        </Label>
        <Input
          id="name"
          {...register('name')}
          placeholder="Your full name"
          className="mt-2 text-gray-900 placeholder:text-gray-400"
        />
        {errors.name && (
          <p className="text-sm text-destructive mt-1">{errors.name.message}</p>
        )}
      </div>

      <div>
        <Label htmlFor="email" className="text-foreground font-medium">
          Email *
        </Label>
        <Input
          id="email"
          type="email"
          {...register('email')}
          placeholder="your.email@example.com"
          className="mt-2 text-gray-900 placeholder:text-gray-400"
        />
        {errors.email && (
          <p className="text-sm text-destructive mt-1">{errors.email.message}</p>
        )}
      </div>

      <div>
        <Label htmlFor="phone" className="text-foreground font-medium">
          Phone *
        </Label>
        <Input
          id="phone"
          type="tel"
          {...register('phone')}
          placeholder="Your phone number"
          className="mt-2 text-gray-900 placeholder:text-gray-400"
        />
        {errors.phone && (
          <p className="text-sm text-destructive mt-1">{errors.phone.message}</p>
        )}
      </div>

      <div>
        <Label htmlFor="service" className="text-foreground font-medium">
          Service *
        </Label>
        <Select
          value={selectedService}
          onValueChange={(value) => setValue('service', value)}
        >
          <SelectTrigger className="mt-2 text-gray-900">
            <SelectValue placeholder="Select a service" />
          </SelectTrigger>
          <SelectContent>
            {services.map((service) => (
              <SelectItem key={service} value={service}>
                {service}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {errors.service && (
          <p className="text-sm text-destructive mt-1">{errors.service.message}</p>
        )}
      </div>

      <div>
        <Label htmlFor="message" className="text-foreground font-medium">
          Message *
        </Label>
        <Textarea
          id="message"
          {...register('message')}
          placeholder="Tell us about your requirements..."
          rows={5}
          className="mt-2 text-gray-900 placeholder:text-gray-400"
        />
        {errors.message && (
          <p className="text-sm text-destructive mt-1">{errors.message.message}</p>
        )}
      </div>

      <Button
        type="submit"
        disabled={isSubmitting}
        className="w-full bg-accent text-accent-foreground hover:bg-accent/90 transition-all duration-200 active:scale-[0.98]"
      >
        {isSubmitting ? 'Processing...' : 'Send via WhatsApp'}
      </Button>
    </form>
  );
};

export default ContactForm;
