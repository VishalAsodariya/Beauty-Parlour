
import React from 'react';
import { Check } from 'lucide-react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

const PricingTable = () => {
  const pricingData = [
    {
      name: 'Bridal Makeup Package',
      price: '₹15,000',
      features: [
        'Pre-bridal consultation',
        'HD makeup with premium products',
        'Hair styling & accessories',
        'Draping assistance',
        'Touch-up kit included'
      ],
      highlighted: true
    },
    {
      name: 'Party Makeup',
      price: '₹3,500',
      features: [
        'Professional makeup',
        'Hairstyling',
        'False lashes',
        'Makeup setting spray'
      ],
      highlighted: false
    },
    {
      name: 'Hair Styling',
      price: '₹2,000',
      features: [
        'Wash & blow dry',
        'Professional styling',
        'Hair accessories',
        'Finishing spray'
      ],
      highlighted: false
    },
    {
      name: 'Facial & Skincare',
      price: '₹1,500',
      features: [
        'Deep cleansing',
        'Exfoliation & massage',
        'Face mask treatment',
        'Moisturizing & protection'
      ],
      highlighted: false
    },
    {
      name: 'Waxing Full Body',
      price: '₹1,200',
      features: [
        'Full body waxing',
        'Gentle wax formula',
        'Post-wax care',
        'Smooth skin guarantee'
      ],
      highlighted: false
    },
    {
      name: 'Mehndi Design',
      price: '₹800',
      features: [
        'Traditional patterns',
        'Contemporary designs',
        'Natural henna',
        'Long-lasting color'
      ],
      highlighted: false
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {pricingData.map((plan, index) => (
        <motion.div
          key={plan.name}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
          className={`relative rounded-2xl p-8 transition-all duration-300 ${
            plan.highlighted
              ? 'bg-primary shadow-xl scale-105 ring-2 ring-accent'
              : 'bg-white shadow-lg hover:shadow-xl'
          }`}
        >
          {plan.highlighted && (
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-accent text-accent-foreground px-4 py-1 rounded-full text-sm font-semibold">
              Recommended
            </div>
          )}
          <h3
            className="text-2xl font-bold mb-2 text-foreground"
            style={{ fontFamily: 'Playfair Display, serif' }}
          >
            {plan.name}
          </h3>
          <div className="mb-6">
            <span className="text-4xl font-bold text-accent">{plan.price}</span>
          </div>
          <ul className="space-y-3 mb-8">
            {plan.features.map((feature, i) => (
              <li key={i} className="flex items-start gap-3">
                <Check className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                <span className="text-foreground">{feature}</span>
              </li>
            ))}
          </ul>
          <Button
            className={`w-full transition-all duration-200 active:scale-[0.98] ${
              plan.highlighted
                ? 'bg-accent text-accent-foreground hover:bg-accent/90'
                : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
            }`}
            onClick={() => {
              const contactSection = document.querySelector('#contact');
              if (contactSection) {
                const offset = 80;
                const elementPosition = contactSection.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - offset;
                window.scrollTo({
                  top: offsetPosition,
                  behavior: 'smooth'
                });
              }
            }}
          >
            Book Now
          </Button>
        </motion.div>
      ))}
    </div>
  );
};

export default PricingTable;
