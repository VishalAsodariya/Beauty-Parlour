
import React from 'react';
import { motion } from 'framer-motion';

const GalleryCard = ({ image, title, category, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.05 }}
      className="group relative overflow-hidden rounded-xl shadow-lg cursor-pointer"
    >
      <div className="relative aspect-[4/5] overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        <div className="absolute bottom-0 left-0 right-0 p-6 text-white transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
          <p className="text-sm font-medium tracking-wide uppercase mb-1 text-accent">
            {category}
          </p>
          <h3 className="text-xl font-semibold" style={{ fontFamily: 'Playfair Display, serif' }}>
            {title}
          </h3>
        </div>
      </div>
    </motion.div>
  );
};

export default GalleryCard;
