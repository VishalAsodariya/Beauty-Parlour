
import React from 'react';
import { Star } from 'lucide-react';
import { motion } from 'framer-motion';

const TestimonialCard = ({ name, feedback, rating, service, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="bg-muted/50 rounded-xl p-6 shadow-md hover:shadow-lg transition-all duration-300"
    >
      <div className="flex items-center gap-1 mb-4">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            className={`w-5 h-5 ${
              i < rating ? 'fill-accent text-accent' : 'text-gray-300'
            }`}
          />
        ))}
      </div>
      <p className="text-foreground leading-relaxed mb-4 italic">
        "{feedback}"
      </p>
      <div className="border-t border-border pt-4">
        <p className="font-semibold text-foreground" style={{ fontFamily: 'Playfair Display, serif' }}>
          {name}
        </p>
        <p className="text-sm text-muted-foreground mt-1">{service}</p>
      </div>
    </motion.div>
  );
};

export default TestimonialCard;
